#include <iostream>
#include <list>
using namespace std;


void Task(list<int> &list);
