#pragma once
#include <list>

using namespace std;

void Sort1(list<int> &list);
void Sort2(list<int> &list);


