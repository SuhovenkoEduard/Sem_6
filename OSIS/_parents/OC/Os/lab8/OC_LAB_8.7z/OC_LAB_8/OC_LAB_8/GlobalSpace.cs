﻿using System.Collections.Generic;

namespace OC_LAB_8
{
    class GlobalSpace
    {
        public MyDirectory root = new MyDirectory();
        public static int AmountBlocks = 10;
        public static List<Block> blocks = new List<Block>(AmountBlocks);

        public GlobalSpace()
        {
            for (int i = 0; i < AmountBlocks; i++)
            {
                blocks.Add(null);
            }
        }

        public List<int> getFreeBlocks(int count)
        {
            List<int> indexBlocks = new List<int>();

            for (int i = 0; i < AmountBlocks && count != 0; i++)
            {
                if (blocks[i] == null)
                {
                    indexBlocks.Add(i);
                    count--;
                }
            }

            return indexBlocks;
        }

        public Block GetBlock(int i)
        {
            if (i < AmountBlocks)
            {
                if (blocks[i] == null)
                {
                    blocks[i] = new Block();
                }
                return blocks[i];
            }
            else
                return null;
        }

        public void ClearBlock(int i)
        {
            blocks[i] = null;
        }

        public void AddTextInMyFile(string text, Myfile myfile)
        {
            int countBlocks = text.Length % 128 == 0 ? text.Length / 128 : (text.Length / 128) + 1;

            List<int> blocks = this.getFreeBlocks(countBlocks);

            for (int i = 0; i < blocks.Count; i++)
            {
                Block block = this.GetBlock(blocks[i]);
                string textInBlock = "";
                if (i == blocks.Count - 1)
                {
                    textInBlock = text.Substring(128 * i);
                }
                else
                {
                    textInBlock = text.Substring(128 * i, 128);
                }

                block.text = textInBlock;

                myfile.AddBlock(blocks[i]);

            }
        }

        public int CountFreeSpace()
        {
            int freeSpace = 0;
            for (int i = 0; i < AmountBlocks; i++)
            {
                if (blocks[i] != null)
                {
                    freeSpace += blocks[i].FreeSpace();
                }
                else
                {
                    freeSpace += 128;
                }
            }

            return freeSpace;
        }

    }
}