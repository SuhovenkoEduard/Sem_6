﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OC_LAB_8
{
    public partial class Form1 : Form
    {
        private GlobalSpace globalSpace = new GlobalSpace();
        private MyDirectory RootDirectory;

        private string selectedFile;

        public Form1()
        {
            RootDirectory = globalSpace.root;
            InitializeComponent();
            InitialTree();
            CountSpace();
        }

        private void InitialTree()
        {
            if(Directory.Exists("C:\\Users\\Alex\\Downloads\\OC_LAB_8\\OC_LAB_8\\root"))
            {
                string[] dirs = Directory.GetDirectories("C:\\Users\\Alex\\Downloads\\OC_LAB_8\\OC_LAB_8\\root");
                if (dirs.Length != 0)
                {
                    for (int i = 0; i < dirs.Length; i++)
                    {
                        string directoryName = new DirectoryInfo(dirs[i]).Name;
                        TreeNode dirNode = new TreeNode(directoryName);
                        MyDirectory newMyDirectory = RootDirectory.AddDirectory(directoryName);
                        FillTreeNode(dirNode, dirs[i], newMyDirectory);
                        Root.Nodes.Add(dirNode);
                    }
                }
                string[] files = Directory.GetFiles("C:\\Users\\Alex\\Downloads\\OC_LAB_8\\OC_LAB_8\\root");
                if (files.Length != 0)
                {
                    for (int i = 0; i < files.Length; i++)
                    {
                        string fileName = new FileInfo(files[i]).Name;
                        TreeNode dirNode = new TreeNode(fileName);
                        Root.Nodes.Add(dirNode);
                        RootDirectory.AddFile(fileName, files[i], globalSpace);
                    }
                }
            }
        }

        private void FillTreeNode(TreeNode driveNode, string path, MyDirectory myDirectory)
        {
            try
            {
                string[] dirs = Directory.GetDirectories(path);
                foreach (string dir in dirs)
                {
                    TreeNode dirNode = new TreeNode();
                    dirNode.Text = dir.Remove(0, dir.LastIndexOf("\\") + 1);
                    driveNode.Nodes.Add(dirNode);
                    MyDirectory newMyDirectory = myDirectory.AddDirectory(dirNode.Text);
                FillTreeNode(dirNode, dir, newMyDirectory);
                }
                string[] files = Directory.GetFiles(path);
                foreach (string file in files)
                {
                    TreeNode dirNode = new TreeNode();
                    dirNode.Text = file.Remove(0, file.LastIndexOf("\\") + 1);
                    driveNode.Nodes.Add(dirNode);
                    myDirectory.AddFile(dirNode.Text, file, globalSpace);
                }
            }
            catch (Exception ex) { }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string fileName = Root.SelectedNode.Text;
            if (fileName.Contains(".txt"))
            {
                string fullPath = Root.SelectedNode.FullPath;
                selectedFile = fullPath;
                Myfile myfile = RootDirectory.FindMyFile(fullPath);
                string contentFile = "";

                foreach(int index in myfile.BlocksFiles)
                {
                    contentFile += globalSpace.GetBlock(index).text;
                }
                richTextBox1.Text = contentFile;
            }
            CountSpace();
        }

        private void CreateFile_Click(object sender, EventArgs e)
        {
            string directoryName = "";
            if (Root.SelectedNode != null)
            {
                directoryName = Root.SelectedNode.Text;
            }
            if (!directoryName.Contains(".txt"))
            {
                MyDirectory myDirectory;
                if (!directoryName.Equals(""))
                {
                    string fullPath = Root.SelectedNode.FullPath;
                    myDirectory = RootDirectory.FindMyDirectory(fullPath);
                }
                else
                {
                    myDirectory = RootDirectory;
                }
                string fileName = textBox1.Text;
                if (!fileName.Contains("\\") && !fileName.Equals(""))
                {
                    if (!fileName.Contains(".txt"))
                    {
                        fileName += ".txt";
                    }
                    myDirectory.AddFile(fileName);
                    TreeNode dirNode = new TreeNode(fileName);
                    if (Root.SelectedNode != null)
                    {
                        Root.SelectedNode.Nodes.Add(dirNode);
                    }
                    else
                    {
                        Root.Nodes.Add(dirNode);
                    }
                }
            }
            CountSpace();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void CreateDirectory_Click(object sender, EventArgs e)
        {
            string directoryName = "";
            if (Root.SelectedNode != null)
            {
                directoryName = Root.SelectedNode.Text;
            }
            if (!directoryName.Contains(".txt"))
            {
                MyDirectory myDirectory;
                if (!directoryName.Equals(""))
                {
                    string fullPath = Root.SelectedNode.FullPath;
                    myDirectory = RootDirectory.FindMyDirectory(fullPath);
                }
                else
                {
                    myDirectory = RootDirectory;
                }
                string newDirectory = textBox1.Text;
                if (!newDirectory.Contains("\\") && !newDirectory.Equals("") && !newDirectory.Contains("."))
                {
                    myDirectory.AddDirectory(newDirectory);
                    TreeNode dirNode = new TreeNode(newDirectory);
                    if (Root.SelectedNode != null)
                    {
                        Root.SelectedNode.Nodes.Add(dirNode);
                    }
                    else
                    {
                        Root.Nodes.Add(dirNode);
                    }
                }
            }
            CountSpace();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!selectedFile.Equals(""))
            {
                Myfile myfile = RootDirectory.FindMyFile(selectedFile);
                string text = richTextBox1.Text;

                int countBlocks = text.Length % 128 == 0 ? text.Length / 128 : (text.Length / 128) + 1;

                int a = text.Length;

                if (countBlocks > myfile.BlocksFiles.Count)
                {
                    List<int> blocks =  globalSpace.getFreeBlocks(countBlocks - myfile.BlocksFiles.Count);

                    if (blocks.Count != countBlocks - myfile.BlocksFiles.Count)
                    {
                        //MessageBox
                        Console.WriteLine();
                    } 
                    else
                    {
                        for (int i = 0; i < myfile.BlocksFiles.Count; i++)
                        {
                            globalSpace.ClearBlock(myfile.BlocksFiles[i]);
                        }

                        myfile.BlocksFiles.Clear();

                        globalSpace.AddTextInMyFile(text, myfile);
                    }
                }
            }
            CountSpace();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Root.SelectedNode != null)
            {
                RootDirectory.Delete(Root.SelectedNode.FullPath);
                Root.SelectedNode.Remove();
            }
            CountSpace();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string directoryName = "";
            if (Root.SelectedNode != null)
            {
                directoryName = Root.SelectedNode.Text;
            }
            if (!directoryName.Contains(".txt"))
            {
                MyDirectory myDirectory;
                if (!directoryName.Equals(""))
                {
                    string fullPath = Root.SelectedNode.FullPath;
                    myDirectory = RootDirectory.FindMyDirectory(fullPath);
                }
                else
                {
                    myDirectory = RootDirectory;
                }
                string newFilePath = textBox1.Text;
                if (newFilePath.Contains(".txt") && !newFilePath.Equals(""))
                {
                    string fileName = newFilePath.Remove(0, newFilePath.LastIndexOf("\\") + 1);
                    myDirectory.AddFile(fileName, newFilePath, globalSpace);
                    TreeNode dirNode = new TreeNode(fileName);
                    if (Root.SelectedNode != null)
                    {
                        Root.SelectedNode.Nodes.Add(dirNode);
                    }
                    else
                    {
                        Root.Nodes.Add(dirNode);
                    }
                }
            }
            CountSpace();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string fileName = "";
            if (Root.SelectedNode != null)
            {
                fileName = Root.SelectedNode.Text;
            }
            if (!fileName.Equals("") && fileName.Contains(".txt"))
            {
                Myfile myfile = RootDirectory.FindMyFile(Root.SelectedNode.FullPath);

                using (StreamWriter sw = new StreamWriter(textBox1.Text + "\\" + fileName, false, System.Text.Encoding.Default))
                {
                    string text = "";
                    foreach (int index in myfile.BlocksFiles)
                    {
                        text += globalSpace.GetBlock(index).text;
                    }
                    sw.Write(text);
                }
            }
            CountSpace();
        }

        private void CountSpace()
        {
            AllSpace.Text = (GlobalSpace.AmountBlocks * 128).ToString();
            FreeSpace.Text = globalSpace.CountFreeSpace().ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
