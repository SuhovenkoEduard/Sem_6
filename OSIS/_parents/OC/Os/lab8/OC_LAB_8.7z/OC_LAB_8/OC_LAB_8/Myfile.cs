﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OC_LAB_8
{
    class Myfile
    {
        private List<int> blocksFiles = new List<int>();
        public List<int> BlocksFiles { get => blocksFiles;}

        public void AddBlock(int block)
        {
            BlocksFiles.Add(block);
        }

    }
}
