﻿namespace OC_LAB_8
{
    class Block
    {
        public string text;

        public int FreeSpace()
        {
            return 128 - text.Length;
        }
    }
}