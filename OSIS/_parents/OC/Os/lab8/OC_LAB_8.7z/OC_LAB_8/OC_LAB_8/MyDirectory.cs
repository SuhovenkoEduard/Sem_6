﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OC_LAB_8
{
    class MyDirectory
    {
        private Dictionary<string, Myfile> Files = new Dictionary<string, Myfile>();
        private Dictionary<string, MyDirectory> Directories = new Dictionary<string, MyDirectory>();


        public MyDirectory AddDirectory(string nameDirectory)
        {
            Directories.Add(nameDirectory, new MyDirectory());
            return Directories[nameDirectory];
        }

        public void AddFile(string nameFile, string pathFile, GlobalSpace globalSpace)
        {
            Files.Add(nameFile, new Myfile());
            Myfile myfile = Files[nameFile];
            using (StreamReader sr = new StreamReader(pathFile, System.Text.Encoding.Default))
            {
                string text = "";
                text = sr.ReadToEnd();
                globalSpace.AddTextInMyFile(text, myfile);
            }
        }
        

        

        public void AddFile(string nameFile)
        {
            Files.Add(nameFile, new Myfile());
        }

        public void Delete(string fullPath)
        {
            string[] splits = fullPath.Split('\\');
            if (splits.Length > 1)
            {
                Directories[splits[0]].Delete(fullPath.Remove(0, splits[0].Length + 1));
            }
            else
            {
                if (Directories.ContainsKey(fullPath))
                {
                    Directories.Remove(fullPath);
                }
                else
                {
                    if (Files.ContainsKey(fullPath))
                    {
                        Files.Remove(fullPath);
                    }
                }
            }
        }

        public Myfile FindMyFile(string fullPath)
        {
            string[] splits = fullPath.Split('\\');
            if (splits.Length > 1)
            {
                return Directories[splits[0]].FindMyFile(fullPath.Remove(0, splits[0].Length + 1));
            } else
            {
                return Files[fullPath];
            }
        }

        public MyDirectory FindMyDirectory(string fullPath)
        {
            string[] splits = fullPath.Split('\\');
            if (splits.Length > 1)
            {
                return Directories[splits[0]].FindMyDirectory(fullPath.Remove(0, splits[0].Length + 1));
            }
            else
            {
                return Directories[fullPath];
            }
        }

    }

}
